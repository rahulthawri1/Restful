package com.rest.api.client;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.opencsv.CSVWriter;
import com.rest.api.beans.ResponseAuthInfo;

/**
 * @author rahuldigambart
 *
 */
@Component

public class RestClient {

	static final String url = "https://exemplify.verify.ibm.com//v1.0/endpoint/default/token";

	private static String tokenString;

	private static CSVWriter csvWriter;
	
	//@Scheduled(fixedRate = 120000) 
	
	public static void main() throws IOException {
		RestTemplate restTemplate = null;
		HttpHeaders httpHeaders = null;
		restTemplate = new RestTemplate();

		httpHeaders = new HttpHeaders();

		httpHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<String, String>();

		multiValueMap.add("client_id", "c331166d-0b85-4ca5-ba52-53b0c28a67af");
		multiValueMap.add("client_secret", "XUUJ3Kn6RL");
		multiValueMap.add("grant_type", "client_credentials");
		multiValueMap.add("scope", "openid");

		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<MultiValueMap<String, String>>(multiValueMap,
				httpHeaders);

		ResponseEntity<ResponseAuthInfo> result = restTemplate.exchange(url, HttpMethod.POST, entity,
				ResponseAuthInfo.class);

		if (result.getStatusCode() == HttpStatus.OK) {
			tokenString = result.getBody().getAccess_token();

			System.out.println("Generated token at runtime :- " + tokenString);
		}

		retriveDetails("https://exemplify.verify.ibm.com/v2.0/Users", tokenString);

	}

	public static void retriveDetails(String url, String tokenString) throws IOException {
		RestTemplate restTemplate = null;
		HttpHeaders httpHeaders = null;
		restTemplate = new RestTemplate();
		httpHeaders = new HttpHeaders();
		httpHeaders.set("Authorization", "bearer " + tokenString);
		ResponseEntity<String> result = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity(httpHeaders),
				String.class);

		String data = result.getBody();
		System.out.println(result.getStatusCodeValue());
		System.out.println(result);

		writeJsonResponseIntoCsvFile(data, url);

	}

	public static void writeJsonResponseIntoCsvFile(String content, String url) throws IOException {
		try {
			if (url.contains("Users")) {
				csvWriter = new CSVWriter(new FileWriter(
						"C:/Users" + "/rahuldigambart/Desktop/CsvFileData" + "/RestResults/Userscsv.csv"));
			}else if(url.contains("Groups"))
			{
				csvWriter = new CSVWriter(new FileWriter(
						"C:/Users" + "/rahuldigambart/Desktop/CsvFileData" + "/RestResults/Groupscsv.csv"));
			}

			String string[] = content.split(",");

			csvWriter.writeNext(string);
			csvWriter.flush();
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}
}
