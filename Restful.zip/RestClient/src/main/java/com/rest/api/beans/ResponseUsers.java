package com.rest.api.beans;

import java.io.Serializable;

public class ResponseUsers implements Serializable{
private String name;
private String emails;
private String addresses;
public ResponseUsers() {
	super();
}
public ResponseUsers(String name, String emails, String addresses) {
	super();
	this.name = name;
	this.emails = emails;
	this.addresses = addresses;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmails() {
	return emails;
}
public void setEmails(String emails) {
	this.emails = emails;
}
public String getAddresses() {
	return addresses;
}
public void setAddresses(String addresses) {
	this.addresses = addresses;
}
@Override
public String toString() {
	return "ResponseUsers [name=" + name + ", emails=" + emails + ", addresses=" + addresses + ", getName()="
			+ getName() + ", getEmails()=" + getEmails() + ", getAddresses()=" + getAddresses() + ", getClass()="
			+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
}

}
