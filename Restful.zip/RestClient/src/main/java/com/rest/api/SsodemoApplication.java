package com.rest.api;

import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.rest.api.client.RestClient;

/**
 * @author rahuldigambart
 *
 */
@SpringBootApplication
@EnableScheduling
public class SsodemoApplication {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(SsodemoApplication.class, args);
        RestClient.main();
	}

}
